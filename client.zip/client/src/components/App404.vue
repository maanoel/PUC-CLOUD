<template>

<section class="section-news">

    <div class="container">

        <h1>Página não encontrada</h1>

    </div>

</section>
  
</template>

<script>

export default {
    
}

</script>

<style scoped>

</style>
