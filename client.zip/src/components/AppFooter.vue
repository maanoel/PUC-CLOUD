<template>
  <footer>
    <div class="container text-center mt-0">

      Projeto de exemplo
      
    </div>
  </footer>
</template>

<script>
export default {};
</script>

<style scoped>
footer {
    margin-top: 40px;
    padding: 15px 0;
    background-color: rgba(0,0,0,0.7);
    color: #fff;
}
</style>